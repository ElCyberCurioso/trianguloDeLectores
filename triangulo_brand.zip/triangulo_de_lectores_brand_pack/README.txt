TRIÁNGULO DE LECTORES — BRAND PACK

Files:
- logo-principal-transparent.png — main logo for headers, about pages and branding.
- logo-footer-transparent.png — compact footer/secondary branding.
- icon-1024.png — large standalone brand icon.
- icon-512.png / 256 / 128 / 64 / 48 / 32 / 16 — web/app icon sizes.
- favicon.ico — browser favicon with 16/32/48/64 px variants.
- social-og-1200x630.jpg — dark Open Graph/social sharing image.
- social-og-light-1200x630.jpg — light Open Graph/social sharing image.

Suggested usage:
- favicon.ico: browser tab
- icon-32.png: small UI/icon contexts
- icon-180/192/512: if you later create PWA/app icons, use the closest larger source
- logo-principal-transparent.png: site header
- logo-footer-transparent.png: footer
- social-og-1200x630.jpg: og:image / Twitter/X preview
